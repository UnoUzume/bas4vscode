# Installation
> `npm install --save @types/vscode`

# Summary
This package contains type definitions for Visual Studio Code (https://github.com/microsoft/vscode).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vscode.

### Additional Details
 * Last updated: Fri, 11 Sep 2020 00:54:30 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Visual Studio Code Team, and Microsoft](https://github.com/Microsoft).
