'use strict';

// http://www.ecma-international.org/ecma-262/5.1/#sec-9.11

module.exports = require('is-callable');
